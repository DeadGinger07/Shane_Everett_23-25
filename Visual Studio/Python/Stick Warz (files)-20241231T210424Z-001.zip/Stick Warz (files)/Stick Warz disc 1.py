import tkinter
import tkinter as tk
import pygame
import moviepy
import os
import time
import proglog
proglog.notebook()
import Print
# Import everything needed to edit video clips 
from moviepy.editor import *
  
# loading video dsa gfg intro video 
clip = VideoFileClip("fastwarz.mp4") 
  
# showing clip 
clip.ipython_display(width = 280, height = 320) 
clip.preview(fps = 30)



time.sleep(30)
with open("Print.py") as file:
    exec(file.read())


